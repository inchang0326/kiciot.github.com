#include <Arduino.h>
#define MAX_CHAR	20

#define COL_0	A0
#define COL_1	A1
#define COL_2	A2	
#define COL_3	A3
#define COL_4	A4
#define COL_5	A5
#define COL_6	A6
#define COL_7	A7

#define ROW_0	A8
#define ROW_1	A9
#define ROW_2	A10
#define ROW_3	A11
#define ROW_4	A12
#define ROW_5	A13
#define ROW_6	A14
#define ROW_7	A15

#define MODE_MATRIX_DISPLAY_STOP	0
#define MODE_MATRIX_DISPLAY_SLIDE	1
#define MODE_MATRIX_DISPLAY_STATIC	2

void initMatrixLED();
void MatrixLEDMain();
void SetMatrixChar(const char* chararray );
void SetMatrixLEDMode(int mode);
void ClearMatrixLED();





