#include "MatrixLed.h"

/*
#define A { \
    {0, 0, 0, 1, 1, 0, 0, 0}, \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 1, 1, 1, 1, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}  \
}
*/
#define A { 0x18,0x24,0x24,0x42,0x7E,0x42,0x42,0x42 }

/*	
#define B { \
    {0, 1, 1, 1, 1, 1, 0, 0},  \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 1, 1, 1, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 1, 1, 1, 1, 0, 0} \
}
*/
#define B { 0x7C,0x42,0x42,0x7C,0x42,0x42,0x42,0x7C }
/*
#define C { \
    {0, 0, 0, 1, 1, 0, 0, 0}, \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 0, 0, 1, 1, 0, 0, 0}  \
}
*/
#define C { 0x18,0x24,0x40,0x40,0x40,0x40,0x24,0x18 }

/*
#define D { \
    {0, 1, 1, 1, 1, 0, 0, 0},  \
    {0, 1, 0, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 1, 0, 0}, \
    {0, 1, 1, 1, 1, 0, 0, 0} \
}
*/
#define D { 0x78,0x44,0x42,0x42,0x42,0x42,0x44,0x78 }

/*
#define E  { \
    {0, 1, 1, 1, 1, 1, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 1, 1, 1, 1, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 1, 1, 1, 1, 1, 0}  \
}
*/
#define E { 0x7E,0x40,0x40,0x7E,0x40,0x40,0x40,0x7E }

/*
#define F  { \
    {0, 1, 1, 1, 1, 1, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 1, 1, 1, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}  \
}
*/
#define F { 0x7E,0x40,0x40,0x7C,0x40,0x40,0x40,0x40 }
/*
#define G { \
    {0, 0, 0, 1, 1, 0, 0, 0},  \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 1, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 0, 0, 1, 1, 0, 0, 0} \
}
*/
#define G { 0x18,0x24,0x40,0x40,0x46,0x42,0x24,0x18 }
/*
#define H { \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 1, 1, 1, 1, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}  \
}
*/
#define H { 0x42,0x42,0x42,0x7E,0x42,0x42,0x42,0x42 }
/*
#define I { \
    {0, 0, 0, 0, 1, 0, 0, 0},  \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0} \
}
*/
#define I { 0x08,0x08,0x08,0x08,0x08,0x08,0x08,0x08 }
/*
#define J { \
    {0, 0, 0, 0, 0, 0, 1, 0},  \
    {0, 0, 0, 0, 0, 0, 1, 0}, \
    {0, 0, 0, 0, 0, 0, 1, 0}, \
    {0, 0, 0, 0, 0, 0, 1, 0}, \
    {0, 0, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 0, 0, 1, 1, 0, 0, 0} \
}
*/
#define J { 0x02,0x02,0x02,0x02,0x02,0x42,0x24,0x18 }
/*
#define K { \
    {0, 1, 0, 0, 0, 1, 0, 0},  \
    {0, 1, 0, 0, 1, 0, 0, 0}, \
    {0, 1, 0, 1, 0, 0, 0, 0}, \
    {0, 1, 1, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 1, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 1, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0} \
}
*/
#define K { 0x44,0x48,0x50,0x60,0x50,0x48,0x44,0x42 }
/*
#define L { \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 1, 1, 1, 1, 1, 0}  \
}
*/
#define L { 0x40,0x40,0x40,0x40,0x40,0x40,0x40,0x7E }
/*
#define M { \
    {0, 1, 1, 0, 0, 1, 1, 0},  \
    {0, 1, 0, 1, 1, 0, 1, 0}, \
    {0, 1, 0, 1, 1, 0, 1, 0}, \
    {0, 1, 0, 1, 1, 0, 1, 0}, \
    {0, 1, 0, 1, 1, 0, 1, 0}, \
    {0, 1, 0, 1, 1, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0} \
}
*/
#define M { 0x66,0x5A,0x5A,0x5A,0x5A,0x5A,0x42,0x42 }
/*
#define N { \
    {0, 1, 0, 0, 0, 0, 1, 0},  \
    {0, 1, 1, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 1, 0, 0, 1, 0}, \
    {0, 1, 0, 1, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 1, 0, 1, 0}, \
    {0, 1, 0, 0, 1, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 1, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0} \
}
*/
#define N { 0x42,0x62,0x52,0x52,0x4A,0x4A,0x46,0x42 }
/*
#define O { \
    {0, 0, 0, 1, 1, 0, 0, 0}, \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 0, 0, 1, 1, 0, 0, 0}  \
}
*/
#define O { 0x18,0x24,0x42,0x42,0x42,0x42,0x24,0x18 }
/*
#define P { \
    {0, 1, 1, 1, 1, 1, 0, 0},  \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 1, 1, 1, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0} \
}
*/
#define P { 0x7C,0x42,0x42,0x42,0x7C,0x40,0x40,0x40 }
/*
#define Q { \
    {0, 0, 0, 1, 1, 0, 0, 0}, \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 1, 1, 1, 0}, \
    {0, 0, 1, 0, 0, 1, 1, 0}, \
    {0, 0, 0, 1, 1, 0, 1, 0}  \
}
*/
#define Q { 0x18,0x24,0x42,0x42,0x42,0x4E,0x26,0x1A }
/*
#define R { \
    {0, 1, 1, 1, 1, 1, 0, 0},  \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 1, 1, 1, 1, 0, 0}, \
    {0, 1, 0, 0, 1, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0} \
}
*/
#define R { 0x7C,0x42,0x42,0x42,0x7C,0x48,0x44,0x42 }
/*
#define S { \
    {0, 0, 1, 1, 1, 1, 0, 0},  \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 0, 1, 0, 0, 0, 0, 0}, \
    {0, 0, 0, 1, 1, 1, 0, 0}, \
    {0, 0, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 0, 1, 1, 1, 1, 0, 0} \
}
*/
#define S { 0x3C,0x42,0x40,0x20,0x1C,0x02,0x02,0x3C }
/*
#define T { \
    {0, 0, 1, 1, 1, 1, 1, 0},  \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0} \
}
*/
#define T { 0x3E,0x08,0x08,0x08,0x08,0x08,0x08,0x08 }

/*
#define U { \
    {0, 1, 0, 0, 0, 0, 1, 0},  \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 0, 0, 1, 1, 0, 0, 0} \
}
*/
#define U { 0x42,0x42,0x42,0x42,0x42,0x42,0x24,0x18 }
/*
#define V { \
    {0, 1, 0, 0, 0, 1, 0, 0},  \
    {0, 1, 0, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 1, 0, 0}, \
    {0, 0, 1, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 1, 0, 0, 0, 0}, \
    {0, 0, 0, 1, 0, 0, 0, 0} \
}
*/
#define V { 0x42,0x42,0x42,0x42,0x42,0x42,0x24,0x18 }
/*
#define W { \
    {0, 1, 0, 0, 0, 1, 0, 0},  \
    {0, 1, 0, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 1, 0, 1, 0, 0}, \
    {0, 1, 0, 1, 0, 1, 0, 0}, \
    {0, 1, 0, 1, 0, 1, 0, 0}, \
    {0, 0, 1, 0, 1, 0, 0, 0}, \
    {0, 0, 1, 0, 1, 0, 0, 0}, \
    {0, 0, 1, 0, 1, 0, 0, 0} \
}
*/
#define W { 0x44,0x44,0x54,0x54,0x54,0x28,0x28,0x28 }
/*
#define X { \
    {0, 1, 0, 0, 0, 0, 1, 0},  \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 0, 0, 1, 1, 0, 0, 0}, \
    {0, 0, 0, 1, 1, 0, 0, 0}, \
    {0, 0, 0, 1, 1, 0, 0, 0}, \
    {0, 0, 1, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0}, \
    {0, 1, 0, 0, 0, 0, 1, 0} \
}
*/
#define X { 0x42,0x24,0x18,0x18,0x18,0x24,0x42,0x42 }
/*
#define Y { \
    {0, 1, 0, 0, 0, 1, 0, 0},  \
    {0, 1, 0, 0, 0, 1, 0, 0}, \
    {0, 1, 0, 0, 0, 1, 0, 0}, \
    {0, 0, 1, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 1, 0, 0, 0, 0}, \
    {0, 0, 0, 1, 0, 0, 0, 0}, \
    {0, 0, 0, 1, 0, 0, 0, 0}, \
    {0, 0, 0, 1, 0, 0, 0, 0} \
}
*/
#define Y { 0x44,0x44,0x44,0x28,0x10,0x10,0x10,0x10 }
/*
#define Z { \
    {0, 1, 1, 1, 1, 1, 1, 0},  \
    {0, 0, 0, 0, 0, 0, 1, 0}, \
    {0, 0, 0, 0, 0, 1, 0, 0}, \
    {0, 0, 0, 0, 1, 0, 0, 0}, \
    {0, 0, 0, 1, 0, 0, 0, 0}, \
    {0, 0, 1, 0, 0, 0, 0, 0}, \
    {0, 1, 0, 0, 0, 0, 0, 0}, \
    {0, 1, 1, 1, 1, 1, 1, 0} \
}
*/
#define Z { 0x7E,0x02,0x04,0x08,0x10,0x20,0x40,0x7E }
/*
#define SPACE { \
    {0, 0, 0, 0, 0, 0, 0, 0},  \
    {0, 0, 0, 0, 0, 0, 0, 0}, \
    {0, 0, 0, 0, 0, 0, 0, 0}, \
    {0, 0, 0, 0, 0, 0, 0, 0}, \
    {0, 0, 0, 0, 0, 0, 0, 0}, \
    {0, 0, 0, 0, 0, 0, 0, 0}, \
    {0, 0, 0, 0, 0, 0, 0, 0}, \
    {0, 0, 0, 0, 0, 0, 0, 0} \
}
*/
#define SPACE { 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 }


int cols[8] = {COL_0,COL_1,COL_2,COL_3, COL_4,COL_5,COL_6,COL_7};
int rows[8] = {ROW_0,ROW_1,ROW_2,ROW_3, ROW_4,ROW_5,ROW_6,ROW_7};

#define SPACE_INDEX 26
const byte font[SPACE_INDEX+1][8] = {
    A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,SPACE
};

byte charArr[MAX_CHAR+1];
int gMatrixMode = MODE_MATRIX_DISPLAY_STOP;
int gSaveCharLen;
int gCurCharIndex;
int gCurStartColumnIndex;
int gCurColumnIndex;
int gColumnCounter;

#define INTERVAL	80
int gDisplayInterval;
int gDisplayIntervalCounter;
byte curCharData[8];

void initMatrixLED()
{
	for (int i= 0; i< 8 ;i++ )
	{
		pinMode(cols[i], OUTPUT);
		digitalWrite(cols[i], HIGH);
		
		pinMode(rows[i], OUTPUT);
		digitalWrite(rows[i], LOW);
	}
	gCurCharIndex = 0;
	gCurStartColumnIndex = 0;
	gCurColumnIndex = 0;	
	
	gSaveCharLen = 0 ;	
	gDisplayInterval = INTERVAL;
	gDisplayIntervalCounter = 0;
	gColumnCounter = 0; 

}
void MatrixPerodicDisplay()
{
    	// display 
	digitalWrite(rows[gCurColumnIndex], LOW); // previous row off
	gCurColumnIndex++;
	if ( gCurColumnIndex >= 8 )
		gCurColumnIndex = 0;

	for (int i = 0; i < 8 ; i++ )
	{
		if ( curCharData[gCurColumnIndex] & (0x80 >> i) )
		{
			digitalWrite(cols[i], LOW);
		}
		else
		{
			digitalWrite(cols[i], HIGH);
		}
	}	 
	digitalWrite(rows[gCurColumnIndex], HIGH); // previous row ON
}

void SlideChange()
{
	gDisplayIntervalCounter++;
        if ( gDisplayIntervalCounter < gDisplayInterval)
          return;
        
        gDisplayIntervalCounter = 0;
        gCurStartColumnIndex++;
        if ( gCurStartColumnIndex >= 8 )
        {
            gCurStartColumnIndex = 0;
            gCurCharIndex++;
            if ( gCurCharIndex >= gSaveCharLen )
            {
              gCurCharIndex = 0;
            }
        }
        for(int i = 0; i < 8 ; i++)
        {
           curCharData[i] = (font[charArr[gCurCharIndex]][i] << gCurStartColumnIndex) | \
                (font[charArr[gCurCharIndex + 1]][i] >> (8 - gCurStartColumnIndex));           
        }
}
void StaticChange()
{
	gDisplayIntervalCounter++;
        if ( gDisplayIntervalCounter < (gDisplayInterval * 8))
          return;
        gDisplayIntervalCounter = 0;
        
        gCurStartColumnIndex = 0;

        gCurCharIndex++;
        if ( gCurCharIndex >= gSaveCharLen )
        {
          gCurCharIndex = 0;
        }
        
        for(int i = 0; i < 8 ; i++)
        {
           curCharData[i] = font[charArr[gCurCharIndex]][i];           
        }
}

void MatrixLEDMain()
{
    
	if ( gMatrixMode == MODE_MATRIX_DISPLAY_STOP)
		return;
		 
	MatrixPerodicDisplay();
        if ( gMatrixMode == MODE_MATRIX_DISPLAY_SLIDE)
        {
          SlideChange();
        }
        else if ( gMatrixMode == MODE_MATRIX_DISPLAY_STATIC )
        {
          StaticChange();
        }

}

void SetMatrixChar(const char* chararray )
{
	boolean findNullFlag = false;
	for(int i = 0; i < 	MAX_CHAR ; i++ )
	{
		if ( ('A'<= chararray[i]) && ('Z' >= chararray[i]) )
		{
			charArr[i] = chararray[i] - 'A'; 
		} 
		else if ( chararray[i] == '\0' )
		{
			gSaveCharLen = i;
			charArr[i] = SPACE_INDEX;
			findNullFlag = true;
			break; 
		}
		else
		{
			charArr[i] = SPACE_INDEX; // space
		}
	}
	if (!findNullFlag)
	{
		gSaveCharLen = MAX_CHAR;
		charArr[MAX_CHAR] = SPACE_INDEX;
	}
		
}	
void SetMatrixLEDMode(int mode)
{
	gMatrixMode = mode;
}
void ClearMatrixLED()
{
	gSaveCharLen = 0 ;
	for (int i= 0; i< 8 ;i++ )
	{
		digitalWrite(cols[i], HIGH);
		digitalWrite(rows[i], LOW);
	}
	gCurCharIndex = 0;
	gCurColumnIndex = 0;	
	gCurStartColumnIndex = 0;
	gDisplayIntervalCounter = 0;
	gColumnCounter = 0;
}

